﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapStone
{
    class Program
    {

        private enum Enviroment
        {
            current,
            oceanSide,
            forest,
            city
        }

        private enum Transportation
        {
            DidNotMove,
            Car,
            Plane,
            Train
        }

        private static void Main(string[] args)
        {

            DisplayOpeningScreen();
            DisplayMainMenu();

            DisplayClosingScreen();

        }

        private static void DisplayAddLocation(List<Places> Location)
        {
            string userResponse;
            Enviroment surroundingArea;
            Transportation transport;
            Places newplace = new Places();

            DisplayHeader("Add a new place you visited");
            //
            //created place object
            //
            Places place = new Places();

            //
            //set up place properties
            //
            Console.Write("Enter Name of The Location:");
            newplace.Name = Console.ReadLine();

            Console.Write("Enter Enviroment of The Area:");
            userResponse = Console.ReadLine();
            Enum.TryParse(userResponse, out surroundingArea);
            newplace.Enviroment = surroundingArea;

            Console.Write("How Did You Get There:");
            userResponse = Console.ReadLine();
            Enum.TryParse(userResponse, out transport);
            newplace.Transportation = transport;

            Console.Write("Enter Days Spent At Location");
            userResponse = Console.ReadLine();
            newplace.NumberOfDays = int.Parse(userResponse);


            //
            //add place to location list
            //
            Location.Add(newplace);

            //
            //confirm place to locations
            //
            Console.WriteLine();
            Console.WriteLine($"{newplace.Name} has beem added to locations.");

            DisplayContinuePrompt();

        }


        private static void DisplayMainMenu()
        {
            string menuChoice;
            bool loopRunning = true;
            List<Places> Location;

            //
            // initialize locations
            //
            Location = InitializeTravelLog();

            while (loopRunning)
            {
                Console.Clear();
                Console.WriteLine();
                Console.WriteLine("Main Menu");
                Console.WriteLine();

                Console.WriteLine("\t1) Display Locations");
                Console.WriteLine("\t2) Add a Location");
                Console.WriteLine("\tE) Exit");
                Console.WriteLine();
                Console.Write("Enter Choice:");
                menuChoice = Console.ReadLine();

                switch (menuChoice)
                {
                    case "1":
                        DisplayTravelLog(Location);
                        break;

                    case "2":
                        DisplayAddLocation(Location);
                        break;

                    case "e":
                    case "E":
                        loopRunning = false;
                        break;

                    default:
                        break;
                }
            }
        }

        private static void DisplayHeader(string header)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("\t\t" + header);
            Console.WriteLine();
        }

        private static void DisplayContinuePrompt()
        {
            Console.WriteLine();
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }

        private static void DisplayOpeningScreen()
        {
            Console.WriteLine();
            Console.WriteLine("\t\tWelcome To Your Travel Log!");
            Console.WriteLine();

            DisplayContinuePrompt();
        }

        private static void DisplayClosingScreen()
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("\t\tThank You For Using My App!");
            Console.WriteLine();

            DisplayContinuePrompt();
        }

        private static List<Places> InitializeTravelLog()
        {
            List<Places> Location = new List<Places>();

            Places myPlace1 = new Places();
           // myPlace1.Name = "Current Location";
           // myPlace1.Enviroment = Enviroment.current;
           // myPlace1.Transportation = Transportation.DidNotMove;
           // myPlace1.NumberOfDays = 1;


            
            //Location.Add(myPlace1);
            return Location;
        }


        static void DisplayTravelLog(List<Places> Location)
        {
            double total = 0;

            DisplayHeader("Travel Log");

            //
            //Display Column Headers
            //
            Console.WriteLine("Name".PadRight(25) + "Days Spent".PadLeft(10));
            Console.WriteLine("---------------------".PadRight(25) + "---------".PadLeft(10));

            foreach (Places item in Location)
            {
                Console.Write(item.PlaceInfo().PadRight(25));
                Console.WriteLine(item.NumberOfDays.ToString().PadLeft(10));

                total = total + item.NumberOfDays;
            }

            //
            //Display Total
            //
            Console.WriteLine("---------".PadLeft(35));
            Console.WriteLine(total.ToString().PadLeft(35));

            DisplayContinuePrompt();
        }
        private class Places
        {
            #region FIELDS
            private string _name;

            private Enviroment _enviroment;

            private Transportation _transportation;

            private int _numberofdays;
            #endregion

            #region PROPERTIES
            public string Name
            {
                get { return _name; }
                set { _name = value; }
            }

            public Enviroment Enviroment
            {
                get { return _enviroment; }
                set { _enviroment = value; }
            }

            public Transportation Transportation
            {
                get { return _transportation; }
                set { _transportation = value; }
            }

            public int NumberOfDays
            {
                get { return _numberofdays; }
                set { _numberofdays = value; }
            }
            #endregion

            #region METHODS
            public string PlaceInfo()
            {
                string placeinfo;

                placeinfo = _name;

                return placeinfo;
            }
            #endregion

            #region CONSTRUCTORS

            public Places()
            {

            }

            #endregion

        }
    }
}